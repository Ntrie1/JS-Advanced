function solve() {

    // let stop = {
    //     next: 'depot'
    // }

    function depart() {
        const label = document.querySelector('#info span');
        const departBtn = document.getElementById('depart');
        const arriveBtn = document.getElementById('arrive');
    // departBtn.disabled = true;
    //    const url = `http://localhost:3030/jsonstore/bus/schedule/${stop.next}`
    //    const res = await fetch(url)

    //    stop = await res.json();
    //    label.textContent = `Next Stop ${stop.name}`;
    //    arriveBtn.disabled = false;
    let nextStopId = 'depot'
    if(label.getAttribute('data-next-stop-id') !== null){
        nextStopId = label.getAttribute('data-next-stop-id')

    }
    fetch(`http://localhost:3030/jsonstore/bus/schedule/${nextStopId}`)
    .then(res => res.json())
    .then(stopInfo =>{
        label.setAttribute('data-stop-name', stopInfo.name)
        label.setAttribute('data-next-stop-id', stopInfo.next)
        label.textContent = `Next Stop ${stopInfo.name}`
        
        departBtn.disabled = true;
        arriveBtn.disabled = false;
        
    })
    .catch(err =>{
        label.textContent = 'Error'
    })
    
    }

    function arrive() {
        const label = document.querySelector('#info span');
        const departBtn = document.getElementById('depart');
        const arriveBtn = document.getElementById('arrive');
        let stopName =  label.getAttribute('data-stop-name')
        label.textContent = `Arriving at ${stopName}`
        departBtn.disabled = false;
        arriveBtn.disabled = true;
       
    }

    return {
        depart,
        arrive
    };
}

let result = solve();