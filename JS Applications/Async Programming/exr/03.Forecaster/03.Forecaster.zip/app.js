// function attachEvents() {
//     let getWeatherButton = document.getElementById('submit');
//     let locationInput = document.getElementById('location');
//     getWeatherButton.addEventListener('click', getWeatherHandler);

   
   
//     let conditions = {
//         Sunny: () => '☀',
//         'Partly sunny': () => '⛅',
//          Overcast: () =>  '☁',
//         Rain: () =>  ' ☂',
//         Degrees: () =>   '°',
//     }
   
   
   
//     function getWeatherHandler(){
//         let forecastContainer = document.getElementById('forecast');
//         forecastContainer.style.display = 'block'
//         fetch('http://localhost:3030/jsonstore/forecaster/locations')
//         .then(res => res.json())
//         .then(locations => {
//             let locationName = locationInput.value;
//             let location = locations.find(x => x.name === locationName)
//             console.log(location);
//             return fetch(`http://localhost:3030/jsonstore/forecaster/today/${location.code}`)
//             .then(res=>res.json())
//             .then(currentWeatherReport => ({code: location.code,currentWeatherReport})); 
//         })
//         .then(({code, currentWeatherReport}) =>{
//           let htmlReport = createCurrentWeatherEl(currentWeatherReport);
//           let currentForecastContainer = document.querySelector('#current');
//           currentForecastContainer.appendChild(htmlReport)

//           return fetch(`http://localhost:3030/jsonstore/forecaster/upcoming/${code}`)
//         });


//         function createUpcomingWeatherEl(weatherReport){
//             let forecastInfoDiv = document.createElement('div');
//             forecastInfoDiv.classList.add('forecast-info');
           
//             let upcomingSpan = document.createElement('span');
//             upcomingSpan.classList.add('upcoming');

//             let symbolSpan = document.createElement('span');
//             symbolSpan.classList.add('symbol');
//             symbolSpan.textContent = conditions[weatherReport.forecast.condition]();
           

//             let nameSpan = document.createElement('span')
//             nameSpan.classList.add('forecast-data');
//             nameSpan.textContent = weatherReport.name;

//             let tempSpan = document.createElement('span')
//             tempSpan.classList.add('forecast-data');
//             tempSpan.textContent = `${weatherReport.forecast.low}/${weatherReport.forecast.high}`;

//             let weatherSpan = document.createElement('span')
//             weatherSpan.classList.add('forecast-data');
//             weatherSpan.textContent = weatherReport.forecast.condition;

//             conditionSpan.appendChild(nameSpan);
//             conditionSpan.appendChild(tempSpan);
//             conditionSpan.appendChild(weatherSpan);

//             forecastDiv.appendChild(conditionSymbolSpan);
//             forecastDiv.appendChild(conditionSpan);
            
//             return forecastDiv;
//         }

//         function createDayReport(){
        
//         }

//         function createCurrentWeatherEl(weatherReport){
//             let forecastDiv = document.createElement('div');
//             forecastDiv.classList.add('forecasts');

//             let conditionSymbolSpan = document.createElement('span');
//             conditionSymbolSpan.classList.add('condition', 'symbol');
//             conditionSymbolSpan.textContent = conditions[weatherReport.forecast.condition]();

//             let conditionSpan = document.createElement('span');
//             conditionSpan.classList.add('conditon');

//             let nameSpan = document.createElement('span')
//             nameSpan.classList.add('forecast-data');
//             nameSpan.textContent = weatherReport.name;

//             let tempSpan = document.createElement('span')
//             tempSpan.classList.add('forecast-data');
//             tempSpan.textContent = `${weatherReport.forecast.low}/${weatherReport.forecast.high}`;

//             let weatherSpan = document.createElement('span')
//             weatherSpan.classList.add('forecast-data');
//             weatherSpan.textContent = weatherReport.forecast.condition;

//             conditionSpan.appendChild(nameSpan);
//             conditionSpan.appendChild(tempSpan);
//             conditionSpan.appendChild(weatherSpan);

//             forecastDiv.appendChild(conditionSymbolSpan);
//             forecastDiv.appendChild(conditionSpan);
            
//             return forecastDiv;


//         }
        

//     }

    
// }

// attachEvents();

function attachEvents(){
    const inputLocation = document.querySelector('input#location');
    const getWeatherButton = document.querySelector('input#submit');
    const forecast = document.querySelector('div#forecast');
    const currentWeather = document.querySelector('div#current');
    const upcomingWeather = document.querySelector('div#upcoming');

    const conditions = {
        Sunny:  '&#x2600',
    'Partly sunny':  '&#x26C5' ,
     Overcast:  '&#x2601' ,
     Rain: ' &#x2614',
     Degrees:  '&#176'
    }

    getWeatherButton.addEventListener('click', getWeather);

    function getWeather(){
        fetch('http://localhost:3030/jsonstore/forecaster/locations')
        .then(res => res.json())
        .then(data =>{
            const cityIndex = data.findIndex(el => el.name === inputLocation.value);
            forecast.style.display = 'block'
            if(cityIndex === 1){
                throw new Error();
            }

            let cityCode = data[cityIndex].code;

            //current weather
            fetch(`http://localhost:3030/jsonstore/forecaster/today/${cityCode}`)
            .then((res) => res.json())
            .then((data) => {
                //Main Div 
                const forecasts = document.createElement('div');
                forecasts.className = 'forecasts';

                //consdition info span
                const conditSymbol = document.createElement('span')
                conditSymbol.className = 'condition symbol';
               conditSymbol.innerHTML = conditions[data.forecast.condition]
               forecasts.appendChild(conditSymbol)

                //condition infospan
                let condition = document.createElement('span');
                condition.className = 'condition';
                //span 1
                const span1 = document.createElement('span');
                span1.className = 'forecast-data';
                span1.textContent = data.name;
                condition.appendChild(span1);

                //span 2
                const span2 = document.createElement('span');
                span2.className = 'forecast-data';
                span2.innerHTML = `${data.forecast.low}&#176;/${data.forecast.high}&#176;`;
                condition.appendChild(span2);

                //span 3
                const span3 = document.createElement('span');
                span3.className = 'forecast-data';
                span3.textContent = data.condition;
                condition.appendChild(span3);

                forecast.appendChild(condition);
                currentWeather.appendChild(forecast)

            })

            //upcoming weather 
            fetch(`http://localhost:3030/jsonstore/forecaster/upcoming/${cityCode}`)
            .then(res => res.json())
            .then(data =>{
                const fcInfo = document.createElement('div')
                fcInfo.className = 'forecast-info';

                // each day from the array spans
                data.forecast.forEach(el => {
                    //main span
                    const upcoming = document.createElement('span');
                    upcoming.className = 'upcoming';

                    // symbol span
                    const symbol = document.createElement('span');
                    symbol.className = 'symbol'
                    symbol.innerHTML = conditions[el.condition];
                    upcoming.appendChild(symbol);

                    // forecasr daa firt span
                    const fcData = document.createElement('span');
                    fcData.className = 'forecast-data';
                    fcData.innerHTML = `${el.low}&#176;/${el.high}&#176;`;
                    upcoming.appendChild(fcData);

                    //forecast data secoind span
                    const fcData2 = document.createElement('span');
                    fcData2.className = 'forecast-data';
                    fcData2.textContent = el.condition;
                    upcoming.appendChild(fcData2);

                    fcInfo.appendChild(upcoming)

                });
                upcomingWeather.appendChild(fcInfo);
            })
            .catch(()=> (forecast.textContent = 'Error'))

        })
        .catch(()=> (forecast.textContent = 'Error'))
    }
    




}
attachEvents();
